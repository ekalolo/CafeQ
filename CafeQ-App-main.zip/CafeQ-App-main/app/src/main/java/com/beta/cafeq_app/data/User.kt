package com.beta.cafeq_app.data

data class User(val img: String = "",
                val name: String = "-",
                val email: String = "-",
                val birthdate: String = "-",
                val gender: String = "-",
                val cell: String = "-")