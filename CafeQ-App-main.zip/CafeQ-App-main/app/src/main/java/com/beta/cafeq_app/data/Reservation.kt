package com.beta.cafeq_app.data

data class Reservation(val idCafe: String = "",
                       val chair: Int = 0,
                       val dateTime: String = "-")