package com.beta.cafeq_app.data

data class ReservationDTO(var key: String = "",
                          var idCafe: String = "",
                          var chair: Int = 0,
                          var dateTime: String = "-")