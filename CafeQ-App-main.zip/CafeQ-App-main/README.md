# CafeQ-App
CafeQ an App for Final Project of Interactive System

 An application that provide some information about cafes that's available here. We can book a cafe according to the number of seats available at that time and can book a cafe for the next few days. This project uses Kotlin as programming language and Firebase as database.
